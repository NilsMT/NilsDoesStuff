package DAO

import BD.SessionOracle
import Bean.employe
import java.sql.Connection
import java.sql.*

class DAOEmployeBis(val ss: SessionOracle) {
    var session: SessionOracle? = null
    init {
        this.session=ss
    }

    fun create(em : employe) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="INSERT INTO employe VALUES(?,?,?,?,?)"
        try {
            val stmt: PreparedStatement = conn!!.prepareStatement(requete)// Création d'une requete de type Statemen

            stmt.setInt(1,em.NUEMPL)
            stmt.setString(2,em.NOMEMPL)
            stmt.setInt(3,em.HEBDO)
            stmt.setInt(4,em.AFFECT)
            stmt.setFloat(5,em.SALAIRE)


            stmt.executeQuery() //Le contenu du select est dans ResultSet
            println("Created succesfully")
        }

        catch(e: SQLException){
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle, trigger ou procédure
        }
    }

    fun update(em : employe) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="UPDATE employe e SET e.NOMEMPL = ?,e.AFFECT = ?,e.HEBDO = ?,e.SALAIRE = ? WHERE e.NUEMPL = ?"
        try {
            val stmt: PreparedStatement = conn!!.prepareStatement(requete)// Création d'une requete de type Statemen

            stmt.setString(1,em.NOMEMPL)
            stmt.setInt(2,em.AFFECT)
            stmt.setInt(3,em.HEBDO)
            stmt.setFloat(4,em.SALAIRE)
            stmt.setInt(5,em.NUEMPL)

            stmt.executeQuery() //Le contenu du select est dans ResultSet
            println("Updated succesfully")
        }

        catch(e: SQLException){
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle, trigger ou procédure
        }
    }

    fun delete(em : employe) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="DELETE FROM employe e WHERE e.NUEMPL = ?"
        try {
            val stmt: PreparedStatement = conn!!.prepareStatement(requete)// Création d'une requete de type Statemen

            stmt.setInt(1,em.NUEMPL)

            stmt.executeQuery() //Le contenu du select est dans ResultSet
            println("Deleted succesfully")
        }

        catch(e: SQLException){
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle, trigger ou procédure
        }
    }

    fun read(){
        //var essai = SessionOracle();
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete: String="SELECT * FROM employe"
        try {
            val stmt: Statement = conn!!.createStatement()// Création d'une requete de type Statemen
            val result: ResultSet= stmt.executeQuery(requete) //Le contenu du select est dans ResultSet

            /* Parcourir le résultat du select avec la fonction next();*/
            while (result!!.next()) {

                // getting the value of the id column
                val id = result.getInt("nuempl")
                val nom=result.getString("nomempl")
                val hebdo = result.getInt("hebdo")
                val aff = result.getInt("affect")
                val sal = result.getFloat("salaire")
                println("$id $nom $hebdo $aff $sal")
            }
            result.close()
        }

        catch(e: SQLException){
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle, trigger ou procédure
        }
    }
}