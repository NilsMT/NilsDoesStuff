package DAO

import BD.SessionOracle
import Bean.employe
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.SQLException

class DAOLecture(val ss: SessionOracle) {
    /*
    create or replace package lecture is
    type cur_empl is REF CURSOR ;
    procedure liste_employes( liste_emp out cur_empl) ;

    type cur_proj is REF CURSOR ;
    procedure liste_proj_employe(le_nuempl in number ,liste_proj out cur_proj) ;

    type cur_proj_serv is REF CURSOR ;
    procedure liste_proj_service(le_nuserv in number, liste_proj_serv out cur_proj_serv) ;

    end ;
    */

}