package DAO

import BD.SessionOracle
import Bean.employe
import java.sql.Connection
import java.sql.PreparedStatement
import java.sql.SQLException

class DAOMAJ(val ss: SessionOracle) {

    /*
    PROCEDURE MODIFIER_HEBDO_EMPLOYE (LE_NUEMPL IN NUMBER,  LE_NOUVEAU_HEBDO IN NUMBER);
    PROCEDURE MODIFIER_SALAIRE_EMPLOYE (LE_NUEMPL IN NUMBER,LE_NOUVEAU_SALAIRE IN NUMBER);
    PROCEDURE MODIFIER_TRAVAIL_EMPLOYE (LE_NUEMPL IN NUMBER, LE_NUPROJ IN NUMBER,LE_NOUVEAU_TRAVAIL IN NUMBER);
    PROCEDURE CREER_TRAVAIL(LE_NUEMPL IN NUMBER, LE_NUPROJ IN NUMBER,LE_TRAVAIL IN NUMBER);*/

    var session: SessionOracle? = null
    init {
        this.session=ss
    }

    fun CREER_EMPLOYE(em : employe) {
        var conn: Connection? = null
        conn= session?.getConnectionOracle()
        val requete ="call MAJ.CREER_EMPLOYE(?,?,?,?,?"
        try {
            val stmt: PreparedStatement = conn!!.prepareStatement(requete)// Création d'une requete de type Statemen

            stmt.setInt(1,em.NUEMPL)
            stmt.setString(2,em.NOMEMPL)
            stmt.setInt(3,em.AFFECT)
            stmt.setInt(4,em.HEBDO)
            stmt.setFloat(5,em.SALAIRE)

            stmt.executeQuery() //Le contenu du select est dans ResultSet
            println("Updated succesfully")
        }

        catch(e: SQLException){
            println(e.errorCode)//numéro d'erreur
            println(e.message)// message d'erreur qui provient d'oracle, trigger ou procédure
        }
    }

}