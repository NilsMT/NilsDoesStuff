package Application

import BD.SessionOracle
import Bean.employe
import DAO.DAOEmploye
import DAO.DAOEmployeBis
import DAO.DAOLecture
import DAO.DAOMAJ

fun main(args: Array<String>) {
    var ss= SessionOracle("s3b10a","lol123")

    var dd=DAOEmploye(ss)


    val em = employe(99,"wesh",25,3,1999f)
    dd.create(em)

    em.SALAIRE = 1999.99f
    em.NOMEMPL = "HAHAHAHAHHAHA"
    dd.update(em)

    dd.delete(em)

    println("===================================================")

    var ddb=DAOEmployeBis(ss)

    val emb = employe(99,"wesh",25,3,1999f)

    ddb.create(emb)

    emb.SALAIRE = 1999.99f
    emb.NOMEMPL = "HAHAHAHAHHAHA"
    ddb.update(emb)

    ddb.delete(emb)

    println("===================================================")

    var ddm=DAOMAJ(ss)

    val emm = employe(99,"wesh",25,3,1999f)

    println("===================================================")

    var ddl=DAOLecture(ss)

    val eml = employe(99,"wesh",25,3,1999f)
}