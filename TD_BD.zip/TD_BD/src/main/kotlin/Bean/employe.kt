package Bean

class employe(val NUEMPL : Int, var NOMEMPL : String, var HEBDO : Int, var AFFECT : Int, var SALAIRE : Float) {
    override fun toString() = "$NUEMPL, '$NOMEMPL', $HEBDO, $AFFECT, $SALAIRE"
}